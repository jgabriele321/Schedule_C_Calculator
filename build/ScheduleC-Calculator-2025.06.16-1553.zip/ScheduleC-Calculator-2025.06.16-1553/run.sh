#!/bin/bash
echo "Starting Schedule C Calculator..."
echo "Backend starting on http://localhost:8080"
echo "Open your browser to http://localhost:3000 (if frontend is served)"
echo ""
echo "Press Ctrl+C to stop"
./${PROJECT_NAME}-backend
