Schedule C Calculator - Desktop Package
======================================

This package contains the Schedule C Calculator application.

To run:
1. Double-click run.sh (Mac/Linux) 
2. Open browser to http://localhost:8080
3. Or serve the frontend separately

Files included:
- ScheduleC-Calculator-backend: Go backend server
- frontend/: Built React application
- Sample_Data/: Test CSV files
- run.sh: Startup script

Version: 2025.06.16-1553
Built: Mon Jun 16 15:53:37 BST 2025
